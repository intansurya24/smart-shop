<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">

    <!-- Top Heading & Grid 8 Kategori Icon -->
    <div>
        <div class="text-center max-w-xl mx-auto mb-8">
            <span class="text-xs font-bold uppercase tracking-wider text-brand-600">Jelajahi Produk Kami</span>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">Kategori Produk Smart Shop</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-2">Pilih kategori untuk menyaring gadget dan produk digital favorit Anda.</p>
        </div>

        <!-- 8 Grid Icon Categories -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            <a href="<?php echo e(route('products.index')); ?>" 
               class="p-4 rounded-2xl border text-center transition-all flex flex-col items-center <?php echo e(!request('category') ? 'bg-brand-600 text-white border-brand-600 shadow-lg shadow-brand-500/20' : 'bg-white text-slate-700 border-slate-200/80 hover:border-brand-400 hover:bg-brand-50/50'); ?>">
                <div class="w-12 h-12 rounded-xl <?php echo e(!request('category') ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'); ?> flex items-center justify-center text-xl mb-2">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <span class="text-xs font-bold">Semua</span>
                <span class="text-[10px] opacity-75 mt-0.5">Produk</span>
            </a>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $isActive = request('category') === $cat->slug; ?>
                <a href="<?php echo e(route('products.index', array_merge(request()->query(), ['category' => $cat->slug]))); ?>" 
                   class="p-4 rounded-2xl border text-center transition-all flex flex-col items-center <?php echo e($isActive ? 'bg-brand-600 text-white border-brand-600 shadow-lg shadow-brand-500/20' : 'bg-white text-slate-700 border-slate-200/80 hover:border-brand-400 hover:bg-brand-50/50'); ?>">
                    <div class="w-12 h-12 rounded-xl <?php echo e($isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'); ?> flex items-center justify-center text-xl mb-2">
                        <i class="fa-solid <?php echo e($cat->icon); ?>"></i>
                    </div>
                    <span class="text-xs font-bold line-clamp-1"><?php echo e($cat->name); ?></span>
                    <span class="text-[10px] opacity-75 mt-0.5"><?php echo e($cat->products_count); ?> item</span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Filter Bar & Search Stats -->
    <div class="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-6 shadow-sm">
        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            <?php if(request('category')): ?>
                <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
            <?php endif; ?>

            <!-- Search Field -->
            <div class="md:col-span-5 relative">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama produk, spesifikasi..."
                       class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-brand-600 focus:ring-2 focus:ring-brand-500/20 outline-none">
                <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <i class="fa-solid fa-magnifying-glass text-xs"></i>
                </div>
            </div>

            <!-- Price Range Filter -->
            <div class="md:col-span-4 flex items-center gap-2">
                <input type="number" name="min_price" value="<?php echo e(request('min_price')); ?>" placeholder="Min Rp"
                       class="w-1/2 px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-brand-600 outline-none">
                <span class="text-slate-400">-</span>
                <input type="number" name="max_price" value="<?php echo e(request('max_price')); ?>" placeholder="Maks Rp"
                       class="w-1/2 px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-brand-600 outline-none">
            </div>

            <!-- Sorting Dropdown & Submit -->
            <div class="md:col-span-3 flex items-center gap-2">
                <select name="sort" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:border-brand-600 outline-none">
                    <option value="latest" <?php echo e(request('sort') == 'latest' ? 'selected' : ''); ?>>Terbaru</option>
                    <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Harga: Termurah</option>
                    <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Harga: Termahal</option>
                    <option value="rating" <?php echo e(request('sort') == 'rating' ? 'selected' : ''); ?>>Rating Tertinggi</option>
                </select>

                <button type="submit" class="px-4 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition-all shrink-0">
                    Terapkan
                </button>
            </div>
        </form>

        <!-- Active Filter Tags -->
        <?php if(request('category') || request('q') || request('min_price') || request('max_price')): ?>
            <div class="flex items-center gap-2 flex-wrap pt-4 mt-4 border-t border-slate-100 text-xs">
                <span class="font-bold text-slate-500">Filter Aktif:</span>
                <?php if(request('category')): ?>
                    <span class="px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 font-semibold border border-brand-200 flex items-center gap-1.5">
                        Kategori: <?php echo e($activeCategory ? $activeCategory->name : request('category')); ?>

                        <a href="<?php echo e(route('products.index', array_diff_key(request()->query(), ['category' => '']))); ?>" class="text-brand-500 hover:text-brand-700">&times;</a>
                    </span>
                <?php endif; ?>
                <?php if(request('q')): ?>
                    <span class="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-semibold border border-slate-200 flex items-center gap-1.5">
                        Pencarian: "<?php echo e(request('q')); ?>"
                        <a href="<?php echo e(route('products.index', array_diff_key(request()->query(), ['q' => '']))); ?>" class="text-slate-500 hover:text-slate-800">&times;</a>
                    </span>
                <?php endif; ?>
                <a href="<?php echo e(route('products.index')); ?>" class="text-rose-600 hover:underline font-bold ml-2">Reset Semua Filter</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Product Grid -->
    <div>
        <?php if($products->isEmpty()): ?>
            <div class="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 max-w-lg mx-auto">
                <div class="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-2xl mb-4">
                    <i class="fa-solid fa-box-open"></i>
                </div>
                <h3 class="text-base font-extrabold text-slate-800">Tidak ada produk ditemukan</h3>
                <p class="text-xs text-slate-500 mt-1">Coba gunakan kata kunci pencarian lain atau ubah rentang harga filter Anda.</p>
                <a href="<?php echo e(route('products.index')); ?>" class="inline-block mt-4 px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">
                    Lihat Semua Produk
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="group bg-white rounded-3xl border border-slate-200/80 overflow-hidden hover:shadow-xl hover:shadow-brand-500/10 hover:border-brand-300 transition-all duration-300 flex flex-col">
                        <!-- Image & Badges -->
                        <div class="relative aspect-square overflow-hidden bg-slate-100">
                            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" 
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                            
                            <?php if($product->discount_percent): ?>
                                <span class="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-rose-500 text-white font-black text-[11px] shadow-sm">
                                    -<?php echo e($product->discount_percent); ?>%
                                </span>
                            <?php endif; ?>

                            <span class="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-semibold">
                                <?php echo e($product->category->name); ?>

                            </span>
                        </div>

                        <!-- Details -->
                        <div class="p-5 flex-1 flex flex-col justify-between">
                            <div>
                                <!-- Rating -->
                                <div class="flex items-center gap-1.5 text-xs text-amber-500 mb-2">
                                    <i class="fa-solid fa-star"></i>
                                    <span class="font-bold text-slate-800"><?php echo e(number_format($product->rating_avg, 1)); ?></span>
                                    <span class="text-slate-400">(<?php echo e($product->rating_count); ?>)</span>
                                </div>

                                <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="font-bold text-sm text-slate-900 group-hover:text-brand-600 transition-colors line-clamp-2 leading-snug">
                                    <?php echo e($product->name); ?>

                                </a>

                                <div class="mt-2 text-xs text-slate-400 flex items-center gap-2">
                                    <span>Stok: <?php echo e($product->stock); ?> unit</span>
                                    <span>•</span>
                                    <span><?php echo e($product->weight); ?> gram</span>
                                </div>
                            </div>

                            <div class="mt-4 pt-4 border-t border-slate-100">
                                <div class="flex items-baseline gap-2 mb-3">
                                    <span class="text-base font-extrabold text-brand-600"><?php echo e($product->formatted_price); ?></span>
                                    <?php if($product->formatted_original_price): ?>
                                        <span class="text-xs text-slate-400 line-through"><?php echo e($product->formatted_original_price); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="grid grid-cols-2 gap-2">
                                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                        <button type="submit" class="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-brand-50 text-slate-700 hover:text-brand-600 text-xs font-bold transition-colors flex items-center justify-center gap-1.5" title="Tambah ke Keranjang">
                                            <i class="fa-solid fa-cart-plus"></i> +Keranjang
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="py-2.5 px-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold transition-colors text-center flex items-center justify-center">
                                        Detail
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination -->
            <div class="mt-10">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['title' => 'Katalog Produk & Kategori - Smart Shop'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\toko2\resources\views/products/index.blade.php ENDPATH**/ ?>
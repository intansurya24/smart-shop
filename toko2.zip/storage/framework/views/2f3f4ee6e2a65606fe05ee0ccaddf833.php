<?php $__env->startSection('page_title', 'Data Produk Toko'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <!-- Top Action Bar -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h2 class="text-lg font-extrabold text-slate-900">Manajemen Katalog Produk</h2>
            <p class="text-xs text-slate-500">Tambah, edit informasi, perbarui stok, atau hapus produk.</p>
        </div>
        <a href="<?php echo e(route('admin.products.create')); ?>" 
           class="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-md shadow-brand-500/20 transition-all flex items-center gap-2">
            <i class="fa-solid fa-plus"></i> Tambah Produk Baru
        </a>
    </div>

    <!-- Filter & Search Card -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <form action="<?php echo e(route('admin.products.index')); ?>" method="GET" class="flex flex-col sm:flex-row items-center gap-3">
            <div class="flex-1 w-full relative">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama produk..." 
                       class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-brand-600 outline-none">
                <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <i class="fa-solid fa-magnifying-glass text-xs"></i>
                </div>
            </div>

            <select name="category" class="w-full sm:w-56 px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-none">
                <option value="">Semua Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="w-full sm:w-auto px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-brand-600 transition-colors">
                Filter
            </button>
        </form>
    </div>

    <!-- Products Table -->
    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-700">
                <thead class="bg-slate-50 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                    <tr>
                        <th class="py-3.5 px-6">Produk</th>
                        <th class="py-3.5 px-6">Kategori</th>
                        <th class="py-3.5 px-6">Harga</th>
                        <th class="py-3.5 px-6">Stok & Berat</th>
                        <th class="py-3.5 px-6">Rating</th>
                        <th class="py-3.5 px-6">Unggulan</th>
                        <th class="py-3.5 px-6 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="py-4 px-6">
                                <div class="flex items-center gap-3">
                                    <img src="<?php echo e($prod->image_url); ?>" alt="<?php echo e($prod->name); ?>" class="w-12 h-12 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0">
                                    <div class="min-w-0">
                                        <p class="font-extrabold text-slate-900 line-clamp-1 max-w-xs"><?php echo e($prod->name); ?></p>
                                        <p class="text-[10px] text-slate-400 font-mono mt-0.5">Slug: <?php echo e($prod->slug); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="py-4 px-6 font-semibold"><?php echo e($prod->category->name); ?></td>
                            <td class="py-4 px-6 font-black text-brand-700"><?php echo e($prod->formatted_price); ?></td>
                            <td class="py-4 px-6">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?php echo e($prod->stock <= 5 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'); ?>">
                                    <?php echo e($prod->stock); ?> unit
                                </span>
                                <span class="text-[10px] text-slate-400 block mt-0.5"><?php echo e($prod->weight); ?> gr</span>
                            </td>
                            <td class="py-4 px-6">
                                <span class="text-amber-500 font-bold flex items-center gap-1">
                                    <i class="fa-solid fa-star text-[10px]"></i> <?php echo e(number_format($prod->rating_avg, 1)); ?>

                                </span>
                            </td>
                            <td class="py-4 px-6">
                                <?php if($prod->is_featured): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-bold">Ya</span>
                                <?php else: ?>
                                    <span class="text-slate-400 text-[10px]">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-6 text-right">
                                <div class="inline-flex items-center gap-1.5">
                                    <a href="<?php echo e(route('products.show', $prod->slug)); ?>" target="_blank"
                                       class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors" title="Lihat Toko">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.products.edit', $prod->id)); ?>" 
                                       class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-brand-50 hover:text-brand-600 flex items-center justify-center transition-colors" title="Edit">
                                        <i class="fa-solid fa-pen-to-square text-xs"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.products.destroy', $prod->id)); ?>" method="POST" onsubmit="return confirm('Hapus produk ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="w-8 h-8 rounded-lg bg-slate-100 hover:bg-rose-50 hover:text-rose-600 flex items-center justify-center transition-colors" title="Hapus">
                                            <i class="fa-solid fa-trash text-xs"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="py-8 text-center text-slate-400">Tidak ada produk yang sesuai dengan filter.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="p-6 border-t border-slate-100">
            <?php echo e($products->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', ['title' => 'Data Produk - Admin Smart Shop'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\toko2\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
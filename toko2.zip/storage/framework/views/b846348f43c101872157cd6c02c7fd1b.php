<?php $__env->startSection('page_title', 'Edit Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto space-y-6">

    <div class="flex items-center justify-between">
        <a href="<?php echo e(route('admin.products.index')); ?>" class="text-xs font-bold text-slate-500 hover:text-brand-600 flex items-center gap-1.5">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Data Produk
        </a>
    </div>

    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-10">
        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Preview Gambar Saat Ini -->
            <div class="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-16 h-16 rounded-xl object-cover bg-white border border-slate-200">
                <div>
                    <span class="text-xs font-bold text-slate-700">Gambar Saat Ini</span>
                    <p class="text-[11px] text-slate-400 truncate max-w-md"><?php echo e($product->image); ?></p>
                </div>
            </div>

            <!-- Nama & Kategori -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Nama Produk</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-brand-600 outline-none">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Kategori</label>
                    <select name="category_id" required class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 outline-none">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $product->category_id) == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Harga & Diskon -->
            <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Harga Jual (Rp)</label>
                    <input type="number" name="price" value="<?php echo e(old('price', (int) $product->price)); ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:bg-white focus:border-brand-600 outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Harga Coret / Asli</label>
                    <input type="number" name="original_price" value="<?php echo e(old('original_price', (int) $product->original_price)); ?>"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-500 focus:bg-white focus:border-brand-600 outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Stok Unit</label>
                    <input type="number" name="stock" value="<?php echo e(old('stock', $product->stock)); ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-brand-600 outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Berat (Gram)</label>
                    <input type="number" name="weight" value="<?php echo e(old('weight', $product->weight)); ?>" required
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-brand-600 outline-none">
                </div>
            </div>

            <!-- Ganti Gambar -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Ubah URL Gambar Online</label>
                    <input type="url" name="image_url" value="<?php echo e(old('image_url', str_starts_with($product->image, 'http') ? $product->image : '')); ?>"
                           class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:border-brand-600 outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Atau Upload Gambar Baru</label>
                    <input type="file" name="image_file" accept="image/*"
                           class="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:border-brand-600 outline-none file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-brand-50 file:text-brand-700">
                </div>
            </div>

            <!-- Spesifikasi Teknis -->
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Spesifikasi Teknis</label>
                <textarea name="specification" rows="4"
                          class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:bg-white focus:border-brand-600 outline-none"><?php echo e(old('specification', $product->specification)); ?></textarea>
            </div>

            <!-- Deskripsi Lengkap -->
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Deskripsi Lengkap</label>
                <textarea name="description" rows="5" required
                          class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-brand-600 outline-none"><?php echo e(old('description', $product->description)); ?></textarea>
            </div>

            <!-- Featured Toggle -->
            <div class="flex items-center gap-3">
                <input type="checkbox" id="is_featured" name="is_featured" value="1" <?php echo e(old('is_featured', $product->is_featured) ? 'checked' : ''); ?>

                       class="w-4 h-4 rounded text-brand-600 border-slate-300 focus:ring-brand-500">
                <label for="is_featured" class="text-xs font-bold text-slate-700 cursor-pointer">
                    Tampilkan sebagai Produk Unggulan di Halaman Beranda (Featured)
                </label>
            </div>

            <!-- Action Buttons -->
            <div class="flex items-center justify-end gap-3 pt-6 border-t border-slate-100">
                <a href="<?php echo e(route('admin.products.index')); ?>" class="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs">
                    Batal
                </a>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-md shadow-brand-500/20 transition-all">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', ['title' => 'Edit Produk: ' . $product->name . ' - Admin Smart Shop'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\toko2\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>